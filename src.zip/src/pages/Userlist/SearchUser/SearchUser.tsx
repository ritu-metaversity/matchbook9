import { FC } from "react";
import { AiOutlineFileExcel, AiOutlineFilePdf } from "react-icons/ai";
import "./styles.scss";

interface ActiveUsersProps {
    setSearchQuery: (query: string) => void;
    searchQuery: string;
}

const SearchUser: FC<ActiveUsersProps> = ({ searchQuery, setSearchQuery }) => {
    return (
        <div className="search" >
            <div className="format">
                <p
                    className="pdf-icon"
                    style={{ cursor: "pointer" }}
                // onClick={handleDownload}
                >
                    <span className="icon">
                        <AiOutlineFilePdf />
                    </span>
                    <span className="pdf">PDF</span>
                </p>

                <p className="excel-icon">
                    <span className="icon">
                        <AiOutlineFileExcel />
                    </span>
                    <span className="excel">Excel</span>
                </p>
            </div>
            <div className="dataTables_filter">
                {/* <span className="search" style={{ marginTop: "8px" }}>
          Search:
        </span> */}
                <form>
                    <label >Search:
                        <input
                            type="text"
                            onChange={(e) => setSearchQuery(e.target.value)}
                            value={searchQuery}
                            // placeholder="Search here..."
                            className="form-control datatable-search"
                        />
                    </label>
                </form>
            </div>
        </div>
    );
};

export default SearchUser;
