import { Button, Col, Form, Input, Modal, Row } from "antd";
import type { FC } from "react";
import { useEffect, useState } from "react";
import { CiUndo } from "react-icons/ci";
import { FaSignInAlt } from "react-icons/fa";
import { useDWCMutation } from "../../../store/service/gameListService";

interface FieldType {
    username?: string;
    password?: string;
    amount?: number;
}

interface Props {
    selectedItem: {
        id: string;
        userId: string;
        username: string;
        accountType: string;
        chips: string;
        pname: string;
        pts: string;
        clientPl: string;
        clientPlPercentage: string;
        exposure: string;
        availabePts: string;
        betLock: boolean;
        accountLock: boolean;
        vcLock: boolean;
        lcLock: boolean;
        active: boolean;
        password: string;
        appUrl: string;
        netExposure: number;
    };
    firstRow: string;
    firstType: string;
    secontRow: string;
    secontType: string;
    disable:boolean;

}

const Limit: FC<Props> = ({ selectedItem, firstRow, secontRow, secontType, disable, firstType }) => {
    const [amount, setAmount] = useState<number>(0);
    const [trigger, { data }] = useDWCMutation();

    useEffect(() => {
        if (selectedItem?.userId) {
            trigger({
                userId: selectedItem.userId
            });
        }
    }, [selectedItem]);

    console.log(data?.data, "datadatadatadata");

    const onFinish = (values: any) => {
        console.log("Success:", values);
    };

    const onFinishFailed = (errorInfo: any) => {
        console.log("Failed:", errorInfo);
    };

    return (
        <div>
            <Form
                name="basic"
                initialValues={{ remember: true }}
                onFinish={onFinish}
                onFinishFailed={onFinishFailed}
                autoComplete="off"
            >
                <Row gutter={[16, 0]}>
                    <Col xl={8} xs={8}>
                        <Form.Item<FieldType> label={firstRow} name={firstRow}></Form.Item>
                    </Col>
                    <Col xl={16} xs={16}>
                       <Input type={firstType} disabled={disable}  style={{textAlign:"right"}}/>
                    </Col>
                </Row>
                <Row gutter={[16, 0]}>
                    <Col xl={8} xs={8}>
                        <Form.Item<FieldType> label={secontRow}></Form.Item>
                    </Col>
                    <Col xl={16} xs={16}>
                        <Form.Item<FieldType> name={secontRow}
                            rules={[{ required: true, message: 'Please fill in this field' }]}>
                            <Input type={secontType} onChange={(e) => setAmount(+e.target.value)} style={{textAlign:"right"}} />
                        </Form.Item>
                    </Col>
                </Row>
                <Row gutter={[16, 0]}>
                    <Col xl={8} xs={8}>
                        <Form.Item<FieldType> label="Transaction Password" name="password"></Form.Item>
                    </Col>
                    <Col xl={16} xs={16}>
                        <Form.Item<FieldType> name={"password"}>
                            <Input type="password" />
                        </Form.Item>
                    </Col>
                </Row>
                <Form.Item className="modals_button">
                    <Button type="dashed" className="btn btn-submit" data-dismiss="modal"><CiUndo style={{ marginRight: "8px" }} />Back</Button>
                    <Button className="btn-submit" htmlType="submit">
                        Submit
                        <FaSignInAlt style={{ marginLeft: "8px" }} />
                    </Button>
                </Form.Item>
            </Form>
        </div>
    );
};

export default Limit;