import UserHeader from './Header/UserHeader'
import './Userlist.scss'

const Userlist = () => {
  return (
    <div>
        <UserHeader />
        </div>
  )
}

export default Userlist