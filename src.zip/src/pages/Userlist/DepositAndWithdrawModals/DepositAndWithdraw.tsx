import { Button, Col, Form, Input, Row } from "antd"
import './styles.scss'
import type { FC} from "react";
import { useEffect, useState } from "react"
import { useDWCMutation } from "../../../store/service/gameListService"
import { CiUndo } from "react-icons/ci"
import { FaSignInAlt } from "react-icons/fa"

type FieldType = {
    username?: string
    password?: string
    amount?: number
    remark?: string
}

type Props = {
    id: string
    userId: string,
    username: string
    accountType: string
    chips: string
    pname: string
    pts: string
    clientPl: string
    clientPlPercentage: string
    exposure: string
    availabePts: string
    betLock: boolean
    accountLock: boolean
    vcLock: boolean
    lcLock: boolean
    active: boolean
    password: string,
    appUrl: string
    netExposure: number
}

const DepositAndWithdraw:FC<Props>= ({ selectedItem }) => {
    const [amount, setAmount ] = useState(0)

    const [trigger, {data}] = useDWCMutation();

    useEffect(()=>{
        trigger({
            userId:selectedItem?.userId
        })
    }, [selectedItem])


    console.log(data?.data, "datadatadatadata")



    const onFinish = (values: any) => {
        console.log("Success:", values)
    }

    const onFinishFailed = (errorInfo: any) => {
        console.log("Failed:", errorInfo)
    }
    return (
        <div>
            <Form
                name="basic"
                initialValues={{ remember: true }}
                onFinish={onFinish}
                onFinishFailed={onFinishFailed}
                autoComplete="off"
            >
                <Row>
                    <Col xl={8} xs={8}>
                        <Form.Item<FieldType> label={data?.data?.parentName} name="username"></Form.Item>
                    </Col>
                    <Col xl={16} xs={16}>

                        <span className="popup-box" id="deposite-first">{data?.data?.parentAmount}</span>
                        <span className="popup-box" id="deposite-first-diff">{amount != 0 && (Number(data?.data?.parentAmount) - Number(amount))}</span>
                    </Col>
                </Row>
                <Row>
                    <Col xl={8} xs={8}>
                        <Form.Item<FieldType> label={data?.data?.childName} name="username"></Form.Item>
                    </Col>
                    <Col xl={16} xs={16}>
                        <span className="popup-box" id="deposite-first">{Number(data?.data?.childAmount).toFixed(2)}</span>
                        <span className="popup-box" id="deposite-first-diff">{amount != 0 && (Number(data?.data?.childAmount) + Number(amount))?.toFixed(2)}</span>
                    </Col>
                </Row>
                <Row>
                    <Col xl={8} xs={8}>
                        <Form.Item<FieldType> label="Amount"></Form.Item>
                    </Col>
                    <Col xl={16} xs={16}>
                        <Form.Item<FieldType> name="amount"
                        rules={[{ required: true, message: 'Please fill in this field' }]}
                        >
                            <Input type="number" onChange={(e)=>setAmount(+e.target.value)} style={{textAlign:"right"}}/>
                        </Form.Item>
                    </Col>
                </Row>
                <Row>
                    <Col xl={8} xs={8}>
                        <Form.Item<FieldType> label="Remark" name="username"></Form.Item>
                    </Col>
                    <Col xl={16} xs={16}>
                        <Form.Item<FieldType> name="remark">
                            <Input.TextArea rows={4} />
                        </Form.Item>
                    </Col>
                </Row>
                <Row>
                    <Col xl={8} xs={8}>
                        <Form.Item<FieldType> label="Transaction Password" name="username"></Form.Item>
                    </Col>
                    <Col xl={16} xs={16}>
                        <Form.Item<FieldType> name="password">
                            <Input type="password" />
                        </Form.Item>
                    </Col>
                </Row>
                <Form.Item className="modals_button"> 
                    <Button type="dashed" className="btn btn-submit" data-dismiss="modal"><CiUndo style={{marginRight:"8px"}}/>Back</Button>
                    <Button className="btn-submit" htmlType="submit">
                    submit
                    <FaSignInAlt style={{marginLeft:"8px"}} />
                    </Button>
                </Form.Item>
            </Form>
        </div>
    )
}

export default DepositAndWithdraw
