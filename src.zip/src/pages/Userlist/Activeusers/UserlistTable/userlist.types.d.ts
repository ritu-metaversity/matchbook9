interface UserDataList {
    age(age: any): unknown;
    total(total: any): unknown;
    id: string;
    userId: string;
    username: string;
    accountType: string;
    chips: string;
    pname: string;
    pts: string;
    clientPl: string;
    clientPlPercentage: string;
    exposure: string;
    availabePts: string;
    betLock: boolean;
    accountLock: boolean;
    vcLock: boolean;
    lcLock: boolean;
    active: boolean;
    password: string;
    appUrl: string;
    netExposure: number;
  }