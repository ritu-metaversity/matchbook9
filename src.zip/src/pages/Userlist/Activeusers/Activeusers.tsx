import type React from "react";
import { useEffect } from "react";
import { useActiveUserListMutation } from "../../../store/service/gameListService";
import UserlistTable from "./UserlistTable/UserlistTable";
import type { UserData, UserDataListResponse } from "../../../store/service/gameListService.types";
import SearchUser from "../SearchUser/SearchUser";

interface ActiveUsersProps {
  userId: string;
  setSearchParams: (params: any) => void;
  setSearchQuery: (query: string) => void;
  searchQuery: string;
}

const Activeusers: React.FC<ActiveUsersProps> = ({ userId, setSearchQuery, searchQuery}) => {
  const [trigger, { data, isLoading }] = useActiveUserListMutation();

  useEffect(() => {
    trigger({
      id: userId,
      index: 0,
      noOfRecords: 100,
      totalPages: 2,
      username: searchQuery
    });
  }, [userId, searchQuery]);

  const filteredData: UserDataListResponse[] | undefined = data?.data?.dataList?.filter(
    (item) =>
      item?.username?.toLowerCase().includes(searchQuery?.toLowerCase())
  );

  const sortedData: UserDataListResponse[] | undefined = filteredData?.slice().sort((a: UserDataListResponse, b: UserDataListResponse) => a?.id - b?.id);

  const getRowClassName = (record: UserDataListResponse, index: number): string => {
    return index % 2 === 0 ? "even_row" : "odd_row";
  };

  return (
    <>
    <SearchUser
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        />
    <div className="active_user-table">
      <UserlistTable  
        filteredData={sortedData}
        getRowClassName={getRowClassName}
        setSearchQuery={setSearchQuery}
        isLoading={isLoading}
      />
    </div>
    </>

  );
};

export default Activeusers;
