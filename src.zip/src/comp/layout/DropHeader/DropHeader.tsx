import { FaRegArrowAltCircleDown, FaRegArrowAltCircleUp } from 'react-icons/fa';
import './styles.scss';
import { useState } from 'react';
import { useDroupUserBalanceQuery } from '../../../store/service/gameListService';

const DropHeader = () => {
    const [detailsVisible, setDetailsVisible] = useState(false);
    const [animationHeight, setAnimationHeight] = useState(false);
    const {data} = useDroupUserBalanceQuery();


    console.log(data?.data, "adadadasdasdasd")
    
    // const [data?.data, setdata?.data] = useState([]);
    // useEffect(() => {
    // 	dropDownApi();
    // }, []);
    // const dropDownApi = async () => {
    // 	const apiUrl = '/matchBox/matchBox-userBalance';
    // 	// debugger;
    // 	const Token = localStorage.getItem('token');
    // 	const response = await axiosInstance.post(apiUrl, {}, { headers: { Authorization: `Bearer ${Token}` } });
    // 	setdata?.data(response?.data?.data);
    // };

    return (
        <>
            <div className={`droup_header ${animationHeight ? 'drop-header1' : 'drop-header'}`}>
                <div
                    style={{
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center', padding: '20px 0'
                    }}>
                    {!detailsVisible && (
                        <FaRegArrowAltCircleDown
                            onClick={() => {
                                setAnimationHeight(!animationHeight);
                                setDetailsVisible(true);
                            }}
                            style={{ color: 'white', borderRadius: '50%', fontSize: '20px' }}
                        />
                    )}
                    {detailsVisible && (
                        <FaRegArrowAltCircleUp
                            onClick={() => {
                                setAnimationHeight(!animationHeight);
                                setDetailsVisible(false);
                            }}
                            style={{
                                display: 'flex',
                                justifyContent: 'center',
                                alignItems: 'center',
                                color: 'white',
                                borderRadius: '50%',
                                fontSize: '20px'
                            }}
                        />
                    )}

                    {
                        detailsVisible && <div className="drop-down-cont">
                            <div className="left_details left_side">
                                <p className="top">
                                    <span className="top-left">Upper Level Credit Reference</span>
                                    <span className="top-right">
                                        {Number(data?.data?.userBalanceResponse?.upperLevelCreditRef).toFixed(2)}
                                        
                                    </span>
                                </p>
                                <p className="middle">
                                    <span className="middle-left">Total Master Balance</span>
                                    <span className="middle-right">
                                        {Number(data?.data?.userBalanceResponse?.totalBalance).toFixed(2)}
                                        
                                    </span>
                                </p>
                                <p className="bottom">
                                    <span className="bottom-left">Available Balance </span>
                                    <span className="bottom-right">
                                        {Number(data?.data?.userBalanceResponse?.availableBalance).toFixed(2)}
                                        
                                    </span>
                                </p>
                            </div>
                            <div className="left_details middle_side">
                                <p className="top">
                                    <span className="top-left">Down Level Occupancy Balance</span>
                                    <span className="top-right">
                                        {Number(data?.data?.userDownlineBalance?.downLevelOccupacyBalance).toFixed(2)}
                                        
                                    </span>
                                </p>
                                <p className="middle">
                                    <span className="middle-left">Upper Level</span>
                                    <span className="middle-right">
                                        {Number(data?.data?.userBalanceResponse?.upperLevel).toFixed(2)}
                                        
                                    </span>
                                </p>
                                <p className="bottom">
                                    <span className="bottom-left">Available Balance With Profit/Loss</span>
                                    <span className="bottom-right">
                                        {Number(data?.data?.userBalanceResponse?.availableBalanceWithProfitLoss).toFixed(2)} 
                                        
                                    </span>
                                </p>
                            </div>
                            <div className="left_details right_side">
                                <p className="top">
                                    <span className="top-left">Down Level Credit Referance</span>
                                    <span className="top-right">
                                        {Number(data?.data?.userDownlineBalance?.downLevelCreditRef).toFixed(2)}
                                        
                                    </span>
                                </p>
                                <p className="middle">
                                    <span className="middle-left">Down Level Profit/Loss</span>
                                    <span className="middle-right">
                                        {Number(data?.data?.userDownlineBalance?.downLevelProfitLoss).toFixed(2)}
                                        
                                    </span>
                                </p>
                                <p className="bottom">
                                    <span className="bottom-left">My Profit/Loss</span>
                                    <span className="bottom-right">
                                        {Number(data?.data?.userBalanceResponse?.myProfitLoss).toFixed(2)}
                                        
                                    </span>
                                </p>
                            </div>
                        </div>
                    }

                </div>
            </div>
            {/* </div> */}
        </>
    );
};

export default DropHeader;
