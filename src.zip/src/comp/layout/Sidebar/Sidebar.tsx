import { Menu } from 'antd';
import { useMemo, useState } from 'react';
import { HiOutlineMinusSm } from 'react-icons/hi';
import { FiPlus } from 'react-icons/fi';
import { Link } from 'react-router-dom';
import './sidebar.scss';
import { useLeftMenuDataQuery } from '../../../store/service/gameListService';
// import { Match } from './types'; // Assuming Match type is defined elsewhere

interface Match {
    matchId: number;
    matchName: string;
    date: string;
}

interface Sport {
    matchName: string;
    matchId: any;
    sportId: number;
    sportName: string;
    totalMatch: number;
    matchList: Match[];
}

const Sidebar: React.FC = () => {
    const { data } = useLeftMenuDataQuery();

    const [menuKey, setMenuKey] = useState<string[]>([]);
    const handleClick = (key: string[]) => {
        const newKey: string[] = [];
        if (key?.length && key[key.length - 1]?.toString().includes('sport-')) {
            setMenuKey([key[key.length - 1]]);
            return;
        }
        if (menuKey?.length) {
            for (const currentKey of menuKey) {
                if (key.includes(currentKey)) {
                    newKey.push(currentKey);
                } else {
                    break;
                }
            }
            if (key?.length > menuKey.length) {
                newKey.push(key.pop() as string);
            }
            setMenuKey(newKey);
        } else {
            setMenuKey(key);
        }
    };

    const items = useMemo(() => {
        return data?.data?.map((el:Sport, index: number) => {
            return {
                key: index + 1,
                label: el?.sportName,
                children: el?.matchList?.map((curEl, ind) => { // Specify the type of curEl
                    return {
                        key: curEl?.matchId,
                        icon: <div className="icon-vicon"></div>,
                        label: <Link to={`/detail/${el?.sportId}/${curEl?.matchId}`}> {curEl?.matchName} </Link>
                    };
                })
            };
        });
    }, [data?.data]);

    return (
        <div>
            <Menu
                onOpenChange={handleClick}
                mode="inline"
                items={items}
                inlineIndent={5}
                openKeys={[...menuKey]}
                expandIcon={(props: any) => props.isSubMenu && <div className="icon-div">{props.isOpen ? <HiOutlineMinusSm /> : <FiPlus />}</div>}
                className="sider-menu"
            />
        </div>
    );
};

export default Sidebar;
