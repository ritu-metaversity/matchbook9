import { ImCross } from 'react-icons/im';
import { FC } from 'react';
import Sidebar from '../Sidebar/Sidebar';

interface SiderCompProps {
	toggleCollapsed: boolean;
	setToggleCollapsed: (toggleCollapsed: boolean) => void;
	onClose: () => void;
}

const SiderComp: FC<SiderCompProps> = ({ toggleCollapsed, setToggleCollapsed}) => {
	return (
		<>
			<div className="sider-container">
				<div>
					<h2>Sports</h2>
					<div className="sider-cross-icon" onClick={() => setToggleCollapsed(!toggleCollapsed)}>
						<ImCross />
					</div>
				</div>
				<Sidebar />
			</div>
		</>
	);
};

export default SiderComp;
