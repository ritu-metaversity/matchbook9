import { Link } from 'react-router-dom';

export const  items = [
    {
      key: '1',
      label: (
        <Link   to="/">
          Ball By Ball
        </Link>
      ),
    },
    {
      key: '2',
      label: (
        <Link   to="/">
          Binary
        </Link>
      ),
    },
    {
      key: '3',
      label: (
        <Link   to="/">
         Race 20-20
        </Link>
      ),
    },
    {
      key: '4',
      label: (
        <Link   to="/">
          Queen
        </Link>
      ),
    },
    {
      key: '5',
      label: (
        <Link   to="/">
         Baccarat
        </Link>
      ),
    },
    {
      key: '6',
      label: (
        <Link   to="/">
         Sports Casino
        </Link>
      ),
    },
    {
      key: '7',
      label: (
        <Link   to="/">
        Casino War
        </Link>
      ),
    },
    {
      key: '8',
      label: (
        <Link   to="/">
         Worli
        </Link>
      ),
    },
    {
      key: '9',
      label: (
        <Link   to="/">
         3 Cards Judgement
        </Link>
      ),
    },
    {
      key: '10',
      label: (
        <Link   to="/">
         32 Cards Casino
        </Link>
      ),
    },
    {
      key: '11',
      label: (
        <Link   to="/">
        Live TeenPatti
        </Link>
      ),
    },
    {
      key: '12',
      label: (
        <Link   to="/">
        TeenPatti 2.0
        </Link>
      ),
    },
    {
      key: '13',
      label: (
        <Link   to="/">
       Live Poker
        </Link>
      ),
    },
    {
      key: '14',
      label: (
        <Link   to="/">
       Andar Bahar
        </Link>
      ),
    },
    {
      key: '15',
      label: (
        <Link   to="/">
       Lucky 7
        </Link>
      ),
    },
    {
      key: '16',
      label: (
        <Link   to="/">
       Dragon Tiger
        </Link>
      ),
    },
    {
      key: '17',
      label: (
        <Link   to="/">
      Bollywood Casino
        </Link>
      ),
    },
    {
      key: '18',
      label: (
        <Link   to="/">
      Cricket Casino
        </Link>
      ),
    },
    
  ];


  export const  reports = [
    {
      key: '1',
      label: (
        <Link   to="/">
          Account's Statement
        </Link>
      ),
    },
    {
      key: '2',
      label: (
        <Link   to="/">
         Current Bets
        </Link>
      ),
    },
    {
      key: '3',
      label: (
        <Link   to="/">
        General Repor
        </Link>
      ),
    },
    {
      key: '4',
      label: (
        <Link   to="/">
         Game Report
        </Link>
      ),
    },
    {
      key: '5',
      label: (
        <Link   to="/">
        Casino Report
        </Link>
      ),
    },
    {
      key: '6',
      label: (
        <Link   to="/">
         Profit And Loss
        </Link>
      ),
    },
    {
      key: '7',
      label: (
        <Link   to="/">
        Casino Result Report
        </Link>
      ),
    },
  ];


  export const  user = [
    {
      key: '1',
      label: (
        <Link   to="/">
          Secure Auth Verification
        </Link>
      ),
    },
    {
      key: '2',
      label: (
        <Link   to="/">
        Change Password
        </Link>
      ),
    },
    {
      key: '3',
      label: (
        <Link   to="/">
        Logout
        </Link>
      ),
    },
    
  ];


