// import React from 'react'
import { Route, Routes } from 'react-router-dom'
import './App.scss'
import Login from './pages/login/Login'
import MainLayout from './comp/MainLayout'
import Userlist from './pages/Userlist/Userlist'
import MarketAnalysis from './pages/MarketAnalysis/MarketAnalysis'

function App() {

  return (
    <>
      <main>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/" element={<MainLayout/>} >
        <Route path="/list-clients" element={<Userlist />} />
        <Route path="/active-users" element={<Userlist />} />
        <Route path="/market-analysis" element={<MarketAnalysis />} />

          </Route>
          
         
        </Routes>
      </main>
    </>
  )
}

export default App
