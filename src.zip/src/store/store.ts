import { configureStore } from "@reduxjs/toolkit";
import { setupListeners } from "@reduxjs/toolkit/query/react";
import { loginApi } from "./service/loginService";
import { gameListApi } from "./service/gameListService";

export const store = configureStore({
   reducer: {
      // [globalApi.reducerPath]: globalApi.reducer, 
      [loginApi.reducerPath]: loginApi.reducer,
      [gameListApi.reducerPath]: gameListApi.reducer
    
   },
   middleware: (getDefaultMiddleware) =>
      getDefaultMiddleware().concat(loginApi.middleware).concat(gameListApi.middleware)
        //  .concat(userApi.middleware)
       
});

setupListeners(store.dispatch);
