import reducer from "./reducer"
import { selectors } from "./selectors"
export { reducer as globalReducer, selectors as globalSelectors }