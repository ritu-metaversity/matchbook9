import { BaseQueryFn, FetchArgs, FetchBaseQueryError, fetchBaseQuery } from "@reduxjs/toolkit/query";
import { toast } from "react-toastify";

type ExtraOptions = {
  toastType?: "hasError" | "all";
} | null;

interface GenericResponseType {
  message: string;
  status: boolean;
  data: any;
}

export const getDynamicBaseQuery: (
  baseUrl?: string,
) => BaseQueryFn<string | FetchArgs, unknown, FetchBaseQueryError> = (
  baseUrl,
) => {
  return async (args, WebApi, extraOptions: ExtraOptions) => {
    const rawBaseQuery = fetchBaseQuery({
      baseUrl: baseUrl || "https://adminapi.247idhub.com/admin-new-apis",
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
    });

    const result = await rawBaseQuery(args, WebApi, {});

    handleErrors(result?.error, extraOptions);
    handleData(result?.data, extraOptions);

    return result;
  };
};

const handleErrors = (error: FetchBaseQueryError | undefined, extraOptions: ExtraOptions) => {
  if (error) {
    const { status } = error;
    if (status === 401) {
      handleUnauthorized();
    } else if (["hasError", "all"].includes(extraOptions?.toastType || "")) {
      toast.error((error.data as { message: string })?.message);
    }
  }
};

const handleData = (data: unknown, extraOptions: ExtraOptions) => {
  if (data) {
    const raw: GenericResponseType = data as GenericResponseType;
    if (extraOptions?.toastType) {
      if (
        raw.status === false &&
        ["hasError", "all"].includes(extraOptions?.toastType) &&
        raw.message
      ) {
        toast.error(raw.message);
      }
      if (
        ["all"].includes(extraOptions?.toastType) &&
        raw.status === true &&
        raw.message
      ) {
        toast.success(raw.message);
      }
    }
  }
};

const handleUnauthorized = () => {
  localStorage.clear();
  window.location.replace("/login");
};
