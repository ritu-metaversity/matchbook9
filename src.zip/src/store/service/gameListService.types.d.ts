export interface LiftMenu {
  sportId: number
  sportName: string
  totalMatch: number
  matchList: MatchList[]
}
export interface MatchList {
  matchId: number
  matchName: string
  date: string
}

interface LeftMenuInterFace {
  data: Sport[];
}


interface UserBalanceResponse {
  upperLevelCreditRef: string;
  availableBalance: string;
  totalBalance: string;
  upperLevel: string;
  availableBalanceWithProfitLoss: string;
  myProfitLoss: string;
}

interface UserDownlineBalance {
  downLevelOccupacyBalance: string;
  downLevelCreditRef: string;
  downLevelProfitLoss: string;
}

interface BalanceResponse {
  data: {
    userBalanceResponse: UserBalanceResponse;
    userDownlineBalance: UserDownlineBalance;
  };
}
interface ActiveUserPaylod {
  id: string ,
  index:number,
  noOfRecords:number,
  totalPages:number,
  username:string
}

interface UserDataResponse {
  data: UserDataListResponse;
}

export interface UserDataListResponse {
  username: any
  totalPages: number;
  currentPage: number;
  dataList: UserData[];
}

interface UserData {
  id: string;
  userId: string;
  username: string;
  accountType: string;
  chips: string;
  pname: string;
  pts: string;
  clientPl: string;
  clientPlPercentage: string;
  exposure: string;
  availabePts: string;
  betLock: boolean;
  accountLock: boolean;
  vcLock: boolean;
  lcLock: boolean;
  active: boolean;
  password: string;
  appUrl: string;
  netExposure: number;
}

interface DwcPayload{
  userId:string
}

interface DWCInterface {
  status: boolean;
  message: null | string;
  data: {
      parentName: string;
      parentAmount: string;
      parentId: string;
      childName: string;
      childAmount: string;
      childId: string;
      childUplineAmount: string;
  };
}
