import { createApi } from "@reduxjs/toolkit/query/react"
import { getDynamicBaseQuery } from "./getDynamicBaseQuery"
import type { ActiveUserPaylod, BalanceResponse, DWCInterface, DwcPayload, UserDataResponse } from "./gameListService.types"
export const gameListApi = createApi({
  reducerPath: "gameListApi",
  baseQuery: getDynamicBaseQuery(),
  endpoints: (builder) => ({
    LeftMenuData: builder.query<LeftMenuInterFace, void>({
      query(data) {
        return {
          url: "/enduser/left-menu-data-open",
          method: "POST",
          body: data,
        }
      },
    }),
    DroupUserBalance: builder.query<BalanceResponse, void>({
      query(data) {
        return {
          url: "/matchBox/matchBox-userBalance",
          method: "POST",
          body: data,
        }
      },
    }),
    ActiveUserList: builder.mutation<UserDataResponse, ActiveUserPaylod>({
      query(data) {
        return {
          url: "/user/child-list-active-user",
          method: "POST",
          body: data,
        }
      },
    }),
    InActiveUserList: builder.mutation<UserDataResponse, ActiveUserPaylod>({
      query(data) {
        return {
          url: "/user/child-list",
          method: "POST",
          body: data,
        }
      },
    }),
    DWC: builder.mutation<DWCInterface, DwcPayload>({
      query(data) {
        return {
          url: "/dwc/depositwithdrawdata",
          method: "POST",
          body: data,
        }
      },
    }),
  }),
})

export const {
  useLeftMenuDataQuery,
  useDroupUserBalanceQuery,
  useActiveUserListMutation,
  useInActiveUserListMutation,
  useDWCMutation
} = gameListApi
