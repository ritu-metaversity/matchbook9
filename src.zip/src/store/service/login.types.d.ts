interface LoginPayload {
    userId: string
    password: string
    appUrl: string
  }
  
  interface LoginResponse {
    passwordtype: string
    token: string
    userId: string
    userType: string
    userTypeInfo: number
    username: string
    message: string
    status: false
    partnership:string
  }
  
  